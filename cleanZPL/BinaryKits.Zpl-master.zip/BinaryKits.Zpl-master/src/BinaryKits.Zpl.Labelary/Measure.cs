﻿namespace BinaryKits.Zpl.Labelary
{
    public enum Measure
    {
        /// <summary>
        /// Millimeter
        /// </summary>
        Millimeter,

        /// <summary>
        /// Inch
        /// </summary>
        Inch
    }
}
