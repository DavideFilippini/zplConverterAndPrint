﻿using BinaryKits.Zpl.Label.Elements;

namespace BinaryKits.Zpl.Viewer.Models
{
    public class LabelInfo
    {
        public string DownloadFormatName { get; set; }
        public ZplElementBase[] ZplElements { get; set; }
    }
}
