﻿namespace BinaryKits.Zpl.Viewer.Models
{
    public abstract class FieldDataBase
    {
    }
}
