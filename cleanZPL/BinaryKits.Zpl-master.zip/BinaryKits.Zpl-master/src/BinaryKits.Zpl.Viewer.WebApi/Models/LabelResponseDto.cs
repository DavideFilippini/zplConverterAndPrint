﻿namespace BinaryKits.Zpl.Viewer.WebApi.Models
{
    public class LabelResponseDto
    {
        public LabelItemDto[] Items { get; set; }
    }
}
