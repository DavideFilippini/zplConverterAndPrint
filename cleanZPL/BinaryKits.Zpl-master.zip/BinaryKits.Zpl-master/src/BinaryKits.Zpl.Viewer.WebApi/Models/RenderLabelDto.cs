﻿namespace BinaryKits.Zpl.Viewer.WebApi.Models
{
    public class RenderLabelDto
    {
        public string ImageBase64 { get; set; }
    }
}
