﻿namespace BinaryKits.Zpl.Viewer.WebApi.Models
{
    public class PrintRequestDto
    {
        /// <summary>
        /// Zpl data
        /// </summary>
        public string ZplData { get; set; }
        /// <summary>
        /// Printer IpAddress
        /// </summary>
        public string PrinterIpAddress { get; set; }

    }
}
